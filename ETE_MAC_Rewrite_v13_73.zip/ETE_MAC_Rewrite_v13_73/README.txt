ETE SOLUTIONS INDIA - MAC REWRITE v13.73

FIX
---
v13.72 incorrectly required scanned identities to be AVAILABLE.
MAC Rewrite is intended for already-programmed DUTs, so v13.73 requires PASS state instead.

LOGIN
-----
Username: admin
Password: 9278456590

USE
---
If your Central Server was already patched with v13.72 PATCH_SERVER_ONCE.bat,
do NOT patch it again. Just replace/use this v13.73 MAC Rewrite package.
Check mac_rewrite\config.txt for your live SERVER_URL and ROUTER_n_SOURCE_IP values.
